import UIKit

var str = "Hello, playground"

struct engineType {
    var engine1 = "v9"
    var engine2 = "v4"
    var engine3 = "v7"
}

let engineChoice = engineType()

print("Choice 1 for a engine is the \(engineChoice.engine1) engine")
print("Choice 2 for a engine is the \(engineChoice.engine2) engine")
print("CHoice 3 for a engine is the \(engineChoice.engine3) engine")
